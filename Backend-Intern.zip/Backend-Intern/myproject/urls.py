# myproject/urls.py
from django.contrib import admin
from django.urls import path, include
from myapp.views import HomePageView

urlpatterns = [
    path('admin/', admin.site.urls),  # URL for the Django admin
    path('', HomePageView.as_view(), name='home'),
    path('api/', include('myapp.urls')),  # Include the app's URL configuration
]
