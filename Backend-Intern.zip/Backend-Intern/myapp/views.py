from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import get_user_model
from rest_framework.views import APIView
from ..myproject.permissions import IsAdmin, IsModerator, IsUser
from django.contrib.auth import authenticate

User = get_user_model()

class HomePageView(APIView):
    def get(self, request):
        return Response({"message": "Welcome to the API!"})

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = [permissions.AllowAny]

    def post(self, request, *args, **kwargs):
        data = request.data
        user = User.objects.create_user(
            username=data['username'],
            password=data['password'],
            role=data.get('role', 'User')
        )
        return Response({"message": "User created successfully"})



class LoginView(APIView):
    permission_classes = [permissions.AllowAny]  # Allow any user to try logging in

    def post(self, request):
        # Get the username and password from the request body
        username = request.data.get('username')
        password = request.data.get('password')

        # Authenticate the user
        user = authenticate(username=username, password=password)
        
        # If authentication is successful, generate and return the JWT tokens
        if user is not None:
            refresh = RefreshToken.for_user(user)  # Generate the refresh token
            return Response({
                'refresh': str(refresh),  # Return the refresh token
                'access': str(refresh.access_token),  # Return the access token
            })
        else:
            return Response({"error": "Invalid credentials"}, status=400)



class AdminOnlyView(APIView):
    permission_classes = [IsAdmin]

    def get(self, request):
        return Response({"message": "Hello, Admin!"})

class ModeratorOnlyView(APIView):
    permission_classes = [IsModerator]

    def get(self, request):
        return Response({"message": "Hello, Moderator!"})

class UserOnlyView(APIView):
    permission_classes = [IsUser]

    def get(self, request):
        return Response({"message": "Hello, User!"})
