# myapp/urls.py
from django.urls import path
from .views import RegisterView, LoginView, AdminOnlyView, ModeratorOnlyView, UserOnlyView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('admin/', AdminOnlyView.as_view(), name='admin-only'),
    path('moderator/', ModeratorOnlyView.as_view(), name='moderator-only'),
    path('user/', UserOnlyView.as_view(), name='user-only'),
]
